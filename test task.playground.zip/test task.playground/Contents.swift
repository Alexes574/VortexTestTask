import UIKit

func makeItCool(str: String) -> String {
    var newStr: String = ""
    for char in str.lowercased(){
        if char == "a" { newStr += "@"}
        else if char == "i" { newStr += "1"}
        else if char == "s" { newStr += "$"}
        else if char == "o" { newStr += "0"}
        else if char == "t" { newStr += "+"}
        else { newStr += String(char)}
        
    }
    return newStr
}
 makeItCool(str: "Adi daST")
